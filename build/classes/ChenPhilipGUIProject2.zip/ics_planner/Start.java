

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

public class Start {

    private JFrame frame;

    private JLabel welcome;
    private JButton start;
    private Main main;

    public Start() {
        makeFrame();
        main = null;
    }
    
    public Start(Main main) {
        makeFrame();
        this.main = main;
    }

    private void makeFrame() {
        frame = new JFrame("Planner");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        welcome = new JLabel(readLine("welcome.txt"));
        frame.add(welcome, BorderLayout.PAGE_START);

        ButtonListener actionListener = new ButtonListener();
        start = new JButton("Start");
        start.addActionListener(actionListener);
        frame.add(start, BorderLayout.CENTER);

        // Finish creating the frame.
        frame.pack();
        frame.setVisible(true);
    }

    private String readLine(String fileName) {
        File file = new File(fileName);
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            return br.readLine();
        } catch (Exception FileNotFoundException) {
            return "Oh no! The file is not found!";
        }
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Start main = new Start();
    }

    private class ButtonListener implements ActionListener {

        public void actionPerformed(ActionEvent event) {
            JButton source = (JButton) event.getSource();

            if (source == start) {
                Main main = new Main();
                frame.setVisible(false);
            }

        } // end of method actionPerformed(ActionEvent event)
    } // end of class ButtonListener
}
