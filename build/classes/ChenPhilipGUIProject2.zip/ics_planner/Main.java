

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Main {

    private Calendar calendar;

    private JFrame frame;

    private JPanel centrePanel;
    private JButton nextMonth;
    private JButton prevMonth;

    private JButton exit;
    private Start start;

    public Main() {
        // Create a frame.
        makeFrame();
        start = null;
    }
    
    public Main(Start start) {
        // Create a frame.
        makeFrame();
        this.start = start;
    }

    private void makeFrame() {
        frame = new JFrame("Planner");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
       
        
        makeCentrePanel();
        frame.add(centrePanel, BorderLayout.CENTER);

// Finish creating the frame.
        frame.pack();
        frame.setVisible(true);
    }

    private void makeCentrePanel() {
        PrevNextMonthButtonListener actionListener = new PrevNextMonthButtonListener();
        centrePanel = new JPanel();
        centrePanel.setLayout(new BorderLayout());

        calendar = new Calendar(11, 2019);
        centrePanel.add(calendar, BorderLayout.CENTER);

        nextMonth = new JButton(">");
        nextMonth.addActionListener(actionListener);
        centrePanel.add(nextMonth, BorderLayout.LINE_END);

            prevMonth = new JButton("<");
            prevMonth.addActionListener(actionListener);
            centrePanel.add(prevMonth, BorderLayout.LINE_START);
        

        exit = new JButton("Quit");
        exit.addActionListener(actionListener);
        centrePanel.add(exit, BorderLayout.PAGE_END);
    }

    public static void main(String[] args) {
// TODO code application logic here
        Main main = new Main();

    }

    /* private classes */
    private class PrevNextMonthButtonListener implements ActionListener {

        public void actionPerformed(ActionEvent event) {
            JButton source = (JButton) event.getSource();

            if (source == nextMonth) {
                centrePanel.remove(calendar);
                calendar = Calendar.nextMonth();
                centrePanel.add(calendar, BorderLayout.CENTER);
                centrePanel.revalidate();
            } else if (source == prevMonth) {
                centrePanel.remove(calendar);
                calendar = Calendar.prevMonth();
                centrePanel.add(calendar, BorderLayout.CENTER);
                centrePanel.revalidate();
            } else if (source == exit) {
                System.exit(0);
            }
        } // end of method actionPerformed(ActionEvent event)
    } // end of class ButtonListener
}
