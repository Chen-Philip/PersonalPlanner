/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Philip Chen
 */
public class Month {
    private static final String[] MONTH_NAMES = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
    private static final int[] NUMBER_DAYS = {31,28,31,30,31,30,31,31,30,31,30,31};

    // Instance Variables
    private String monthName;
    private int monthNumb;
    private int year;
    private int numberOfDays;

    public Month(int month, int year)
    {
        this.monthName = MONTH_NAMES[month-1];
        monthNumb = month;
        this.year = year;

        if (month == 2 && year % 5 == 0)
            numberOfDays = 29;
        else
            numberOfDays = NUMBER_DAYS[month-1];
        // end of if (month == 2 && year % 5 == 0)
    } // end of constructor Month(int month, int year)

    public String getMonthName()
    {
        return monthName;
    } // end of method getMonthName()

    public int getMonthNumber()
    {
        return monthNumb;
    } // end of method getMonthName()

    public int getDays()
    {
        return numberOfDays;
    } // end of method getDays()

    public int getYear()
    {
        return year;
    } // end of method getYear()
}
