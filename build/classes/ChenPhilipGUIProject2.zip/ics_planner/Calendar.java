/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.awt.*;
import javax.swing.*;

public class Calendar extends JPanel {

    // Constants
    private static final String[] WEEKDAYS = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    public static final int BASE_MONTH = 9;
    public static final int BASE_YEAR = 2019;
    private static final int BASE_NUMB_OF_LEAP_DAYS = 504;
    private static final int DAYS_IN_YEAR = 365;
    private static final int DAYS_IN_YEAR_FROM_SEPTEMBER = 122;
    private static final int NUMBER_OF_ROWS = 5;
    private static final int NUMBER_OF_COLS = 7;
    private static final int GRID_GAP = 5;

    private static final int DAYPANEL_HEIGHT = 100;
    private static final int DAYPANEL_WIDTH = 150;

    // Variables
    private static Month month;

    private JPanel topPanel;
    private JLabel monthName;
    private JPanel weekdayPanel;
    private JLabel[] weekday;

    private JPanel centrePanel;
    private JPanel[][] dayPanel;
    private JLabel[][] days;

    public Calendar(int monthNumb, int year) {
        month = new Month(monthNumb, year);

        // Create a frame.
        makeCalendarPanel();
    }

    private void makeCalendarPanel() {
        this.setLayout(new BorderLayout());

        makeTopPanel();
        this.add(topPanel, BorderLayout.PAGE_START);

        makeCentrePanel();
        this.add(centrePanel, BorderLayout.CENTER);
    }

    private void makeTopPanel() {
        monthName = new JLabel(month.getMonthName() + " " + month.getYear());

        weekdayPanel = new JPanel();
        weekdayPanel.setLayout(new FlowLayout(FlowLayout.TRAILING, GRID_GAP, GRID_GAP));
        weekday = new JLabel[NUMBER_OF_COLS];
        for (int i = 0; i < NUMBER_OF_COLS; i = i + 1) {
            weekday[i] = new JLabel(WEEKDAYS[i], SwingConstants.CENTER);
            weekday[i].setPreferredSize(new Dimension(DAYPANEL_WIDTH, DAYPANEL_HEIGHT / 3));
            weekdayPanel.add(weekday[i]);
        }

        topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.PAGE_AXIS));
        topPanel.add(monthName);
        topPanel.add(weekdayPanel);
    }

    private void makeCentrePanel() {
        int numberOfDays = 0;
        int dayCounter = 1;

        if (month.getYear() == 2019) {
            for (int m = month.getMonthNumber() - 1; m >= 9; m = m - 1) {
                if ((m - BASE_MONTH) % 2 == 0) {
                    numberOfDays = numberOfDays + 30;
                } else {
                    numberOfDays = numberOfDays + 31;
                }
                // end of if((m-BASE_MONTH)%2 == 0)
            } // end of for (int m = month.getMonthNumber(); m <= 12; m = m + 1)
        } else {
            if (month.getMonthNumber() > 2 && month.getYear() % 4 == 0) {
                numberOfDays = numberOfDays + 1;
            }
            // end of if (month.getYear()%4 == 0)

            for (int m = month.getMonthNumber() - 1; m >= 1; m = m - 1) {
                switch (m) {
                    case 4:
                    case 6:
                    case 9:
                    case 11:
                        numberOfDays = numberOfDays + 30;
                        break;
                    case 2:
                        numberOfDays = numberOfDays + 28;
                        break;
                    default:
                        numberOfDays = numberOfDays + 31;
                } // end of switch(m)                      
            } // end of for (int m = month.getMonthNumber(); m <= 12; m = m + 1)
            numberOfDays = numberOfDays + DAYS_IN_YEAR_FROM_SEPTEMBER + (month.getYear() - BASE_YEAR - 1) * DAYS_IN_YEAR + (month.getYear() - 1) / 4 - BASE_NUMB_OF_LEAP_DAYS;
        }
        int daysBlank = numberOfDays % 7;
        int numRows = NUMBER_OF_ROWS;

        if (daysBlank + month.getDays() > 35) {
            numRows = numRows + 1;
        }
        centrePanel = new JPanel();
        centrePanel.setLayout(new GridLayout(numRows, NUMBER_OF_COLS, GRID_GAP, GRID_GAP));

        dayPanel = new JPanel[numRows][NUMBER_OF_COLS];
        days = new JLabel[numRows][NUMBER_OF_COLS];
        for (int i = 0; i < numRows; i = i + 1) {
            for (int j = 0; j < NUMBER_OF_COLS; j = j + 1) {
                dayPanel[i][j] = new JPanel();
                dayPanel[i][j].setLayout(new BorderLayout());
                dayPanel[i][j].setBackground(Color.cyan);
                dayPanel[i][j].setPreferredSize(new Dimension(DAYPANEL_WIDTH, DAYPANEL_HEIGHT));
                centrePanel.add(dayPanel[i][j]);

                if (i == 0 && j < daysBlank) {
                    days[i][j] = new JLabel();
                } else if (dayCounter <= month.getDays()) {
                    days[i][j] = new JLabel("" + dayCounter);
                    dayCounter = dayCounter + 1;
                } else {
                    days[i][j] = new JLabel();
                }
                // end of if (dayCounter < month.getDays())
                dayPanel[i][j].add(days[i][j], BorderLayout.PAGE_START);
            } // end of for (int j = 0; j < NUMBER_OF_COLS; j = j + 1)
        } // end of for (int i = 0; i < NUMBER_OF_ROWS; i = i + 1)

    }

    public Month getMonth() {
        return month;
    }

    public static Calendar nextMonth() {
        int monthNumber = month.getMonthNumber();
        int year = month.getYear();
        if (monthNumber == 12) {
            monthNumber = 1;
            year = year + 1;
        } else {
            monthNumber = monthNumber + 1;
        }
        // end of if (monthNumber == 12)
        return new Calendar(monthNumber, year);
    }

    public static Calendar prevMonth() {
        int monthNumber = month.getMonthNumber();
        int year = month.getYear();
        if (monthNumber == 1) {
            monthNumber = 12;
            year = year - 1;
        } else {
            monthNumber = monthNumber - 1;
        }
        // end of if (monthNumber == 12)
        return new Calendar(monthNumber, year);
    }

}
